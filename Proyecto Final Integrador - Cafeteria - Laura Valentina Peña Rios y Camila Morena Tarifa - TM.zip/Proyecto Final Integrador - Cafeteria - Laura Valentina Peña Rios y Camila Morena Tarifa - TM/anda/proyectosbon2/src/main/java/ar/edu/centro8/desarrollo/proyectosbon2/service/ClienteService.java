package ar.edu.centro8.desarrollo.proyectosbon2.service;

import ar.edu.centro8.desarrollo.proyectosbon2.model.Cliente;
import ar.edu.centro8.desarrollo.proyectosbon2.repository.ClienteRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ClienteService {

    @Autowired
    private ClienteRepository clienteRepository;

    public List<Cliente> buscarPorNombre(String nombre) {
        return clienteRepository.findByNombreContaining(nombre);
    }

    public List<Cliente> buscarClientesPorNombreSimilar(String nombre) {
        return clienteRepository.findByNombreLike(nombre);
    }

}
