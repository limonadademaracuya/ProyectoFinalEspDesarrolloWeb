package ar.edu.centro8.desarrollo.proyectosbon2.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import ar.edu.centro8.desarrollo.proyectosbon2.model.Producto;

public interface ProductoRepository extends JpaRepository<Producto,Long> {

}
