package ar.edu.centro8.desarrollo.proyectosbon2.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "facturas")
@Getter
@Setter
@NoArgsConstructor
public class Factura {
    // private String forma_de_pago; // en lo q me mandas es el varchar
    // private int nro_pedido;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idFactura;

    @Column(name = "formaDePago", nullable = false)
    private String formaDePago;

    private int nro_pedido;

    public Factura(String formaDePago, int nro_pedido) {
        this.formaDePago = formaDePago;
        this.nro_pedido = nro_pedido;
    }
}
