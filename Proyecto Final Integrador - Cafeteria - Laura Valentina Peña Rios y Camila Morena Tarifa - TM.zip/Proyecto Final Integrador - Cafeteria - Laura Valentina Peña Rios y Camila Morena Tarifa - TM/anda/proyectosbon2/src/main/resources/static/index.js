window.addEventListener('load', ()=> {
    let lon
    let lat

    let temperaturaValor = document.getElementById('temperatura-valor')  
    let temperaturaDescripcion = document.getElementById('temperatura-descripcion')  
    
    let ubicacion = document.getElementById('ubicacion')  
    let iconoAnimado = document.getElementById('icono-animado') 

    let vientoVelocidad = document.getElementById('viento-velocidad') 

// donde consegui el objeto (navigator) https://developer.mozilla.org/es/docs/Web/API/Geolocation/getCurrentPosition
    if(navigator.geolocation){
       navigator.geolocation.getCurrentPosition( posicion => {
           lon = posicion.coords.longitude
           lat = posicion.coords.latitude
           const url = `https://api.openweathermap.org/data/2.5/weather?q=Buenos Aires&lang=es&units=metric&appid=1c25bc53f0639376944706ae72baca25`
// units=metric es algo que me da OpenWeather para tener el clima en °, el appid es mi llave de api tengo limites xq es gratis https://openweathermap.org/price el link de donde saque la api del clima        
fetch(url) 
            .then( response => { return response.json()}) //lo que nos trae de la api lo muestra en json
            .then( data => { //mostrar los datos
                
                let temp = Math.round(data.main.temp)
                //temperatura
                temperaturaValor.textContent = `${temp} ° C`

                let desc = data.weather[0].description
                temperaturaDescripcion.textContent = desc.toUpperCase()
                ubicacion.textContent = data.name
                
                vientoVelocidad.textContent = `${data.wind.speed} m/s`
      // el icono animado son de http://amcharts.com/free-animated-svg-weather-icons/ 
                console.log(data.weather[0].main)  //si quiere el valor de algo en f12, poner en el parentesis data.main.temp
                switch (data.weather[0].main) {
                    case 'Thunderstorm':
                      iconoAnimado.src='animated/thunder.svg'
                      console.log('TORMENTA');
                      break;
                    case 'Drizzle':
                      iconoAnimado.src='animated/rainy-2.svg'
                      console.log('LLOVIZNA');
                      break;
                    case 'Rain':
                      iconoAnimado.src='animated/rainy-7.svg'
                      console.log('LLUVIA');
                      break;
                    case 'Snow':
                      iconoAnimado.src='animated/snowy-6.svg'
                        console.log('NIEVE');
                      break;                        
                    case 'Clear':
                        iconoAnimado.src='animated/day.svg'
                        console.log('LIMPIO');
                      break;
                    case 'Atmosphere':
                      iconoAnimado.src='animated/weather.svg'
                        console.log('ATMOSFERA');
                        break;  
                    case 'Clouds':
                        iconoAnimado.src='animated/cloudy-day-1.svg'
                        console.log('NUBES');
                        break;  
                    default:
                      iconoAnimado.src='animated/cloudy-day-1.svg'
                      console.log('por defecto');
                  }

            })
            .catch( error => {
                console.log(error)
            })
       })
          
    }
})

// Variables globales

const tablaClientesHTML = document.getElementById('tablaClientes');
const nombre = document.getElementById('nombre');
const domicilio = document.getElementById('domicilio');
const telefono = document.getElementById('telefono');
const btnGuardar = document.getElementById('btnGuardar');
let tituloModal = document.getElementById('tituloModal');
let idClienteModificar = 0;

// Event listener para el botón de crear
btnGuardar.addEventListener('click', () => {
    if (tituloModal.innerText === "Modificar Cliente") {
        crearCliente(idClienteModificar);
    } else if (tituloModal.innerText === "Crear Cliente") {
        crearCliente(0);
    }
});

// Eliminar Cliente
async function eliminarCliente(id) {
    await fetch('http://localhost:8080/api/cliente/borrar/' + id, {
        method: 'DELETE',
        headers: {
            'Content-Type': 'application/json'
        }
    })
    .then(() => {
        alert('Cliente eliminado correctamente');
        obtenerClientes();
    })
    .catch(err => {
        console.error('Error al eliminar cliente:', err);
        alert('Error al eliminar el cliente');
    });
}

// Modificar Cliente
async function modificarCliente(id) {
    tituloModal.innerText = "Modificar Cliente";
    modal.style.display = "block"; // muestra el modal

    idClienteModificar = id;
    resetModal();

    let cliente = listaClientes.find(c => c.idCliente === idClienteModificar);

    if (cliente) {
        nombre.value = cliente.nombre;
        domicilio.value = cliente.domicilio;
        telefono.value = cliente.telefono;

        // Envía una solicitud PUT para actualizar el cliente
        await fetch('http://localhost:8080/api/cliente/actualizar/' + id, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                idCliente: id,
                nombre: nombre.value,
                domicilio: domicilio.value,
                telefono: telefono.value
            })
        })
        .then(response => response.json())
        .then(data => {
            console.log('Cliente actualizado:', data);
            alert('Cliente modificado correctamente');
            obtenerClientes();
        })
        .catch(err => {
            console.error('Error al modificar cliente:', err);
        });
    }
}

// Crear Cliente
async function crearCliente(id) {
    let clienteGuardar = {
        idCliente: id,
        nombre: nombre.value,
        domicilio: domicilio.value,
        telefono: telefono.value,
    }
    console.log(clienteGuardar);

    await fetch('http://localhost:8080/api/cliente/crear', {
        method: 'POST',
        mode: 'cors',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(clienteGuardar)
    })
    .then((cliente) => {
        console.log(cliente);
        alert("Cliente guardado");
        modal.style.display = "none";
        obtenerClientes();
        resetModal();
    })
    .catch((err) => {
        console.log(err);
        alert("Error en el alta del cliente");
    });
}

// Traer todos los clientes
let listaClientes = [];
async function obtenerClientes() {
    tablaClientesHTML.innerHTML = '';
    await fetch('http://localhost:8080/api/cliente/traer')
    .then(response => response.json())
    .then(clientes => {
        listaClientes = clientes;
        clientes.forEach(cliente => {
            tablaClientesHTML.innerHTML += `
                <tr>
                    <td>${cliente.idCliente}</td>
                    <td>${cliente.nombre}</td>
                    <td>${cliente.domicilio}</td>
                    <td>${cliente.telefono}</td>
                    <td>
                        <button class="btn btn-danger btn-sm" onclick=eliminarCliente(${cliente.idCliente})>Eliminar</button>
                        <button class="btn btn-success btn-sm" onclick=modificarCliente(${cliente.idCliente})>Modificar</button>
                    </td>
                </tr>
            `;
        });
    })
    .catch(err => {
        console.error('Error al obtener clientes:', err);
        alert('Error al cargar los clientes');
    });
}
obtenerClientes();

async function buscarClientes() {
    const busqueda = document.getElementById('busqueda').value;
    tablaClientesHTML.innerHTML = '';

    await fetch('http://localhost:8080/api/cliente/buscarSimilar/' + busqueda)
    .then(response => response.json())
    .then(clientes => {
        listaClientes = clientes;
        clientes.forEach(cliente => {
            tablaClientesHTML.innerHTML += `
                <tr>
                    <td>${cliente.idCliente}</td>
                    <td>${cliente.nombre}</td>
                    <td>${cliente.domicilio}</td>
                    <td>${cliente.telefono}</td>
                    <td>
                        <button class="btn btn-danger btn-sm" onclick=eliminarCliente(${cliente.idCliente})>Eliminar</button>
                        <button class="btn btn-success btn-sm" onclick=modificarCliente(${cliente.idCliente})>Modificar</button>
                    </td>
                </tr>
            `;
        });
    })
    .catch(err => {
        console.error('Error al obtener clientes:', err);
        alert('Error al cargar los clientes');
    });
}

// Función para resetear el formulario del modal
function resetModal() {
    nombre.value = '';
    domicilio.value = '';
    telefono.value = '';
}

// Modal 
var modal = document.getElementById("myModal");
var btn = document.getElementById("myBtn");
var span = document.getElementsByClassName("close")[0];

// Asigna una función al evento de clic del botón "myBtn".
btn.onclick = function () {
    tituloModal.innerText = "Crear Cliente";
    modal.style.display = "block";
}

// Cuando se presiona este elemento, oculta el modal y llama a resetModal().
span.onclick = function () {
    modal.style.display = "none";
    resetModal();
}

// Si el objetivo del clic es el modal mismo, ocultará el modal y llamará a resetModal().
window.onclick = function (event) {
    if (event.target == modal) {
        modal.style.display = "none";
        resetModal();
    }
    
}